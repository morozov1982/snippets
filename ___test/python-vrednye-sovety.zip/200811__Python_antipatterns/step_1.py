user_name = 'ivan'
userName = 'ivan'  # Java

print(user_name, userName)


class SuperUser:
    pass


def say_hello():
    """

    :return:
    """
    pass


def say_hello_2():
    pass


def say_hello_3():
    pass


age = int('15')  # int example
# print age
print(age)

for a in range(15):
    if a % 2:
        print(a)
    print('---')
