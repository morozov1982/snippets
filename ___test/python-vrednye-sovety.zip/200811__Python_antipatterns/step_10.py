some_text = 'Всем   добрый   вечер!'
some_text_proc = list(map(lambda x: x.strip().upper(), some_text.split()))
print(some_text_proc)
