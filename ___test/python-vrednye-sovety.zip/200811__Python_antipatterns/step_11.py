def calc_avg(data_series):
    # return sum(data_series) / len(data_series)
    try:
        return sum(data_series) / len(data_series)
    except Exception as e:
        pass
        print(f'error: {e}')
        # raise MyException()










user_data = [1, 6, 8, 1, 2, 5]
print(calc_avg(user_data))

user_data_2 = []
print(calc_avg(user_data_2))
# a = calc_avg(user_data_2)
# b = a * 15
# print(b)
