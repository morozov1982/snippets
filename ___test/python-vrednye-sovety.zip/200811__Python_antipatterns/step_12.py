import random
import sys
import time

TASK_SIZE = 10 ** 6
nums = [random.randint(-1000, 1000) for _ in range(TASK_SIZE)]
low_border = -2


def cycle_case():
    start = time.perf_counter()
    tmp = []
    for num in nums:
        tmp.append(num if num > low_border else low_border)
    summ = sum(tmp)
    finish = time.perf_counter()
    print(f'cycle_case: {summ} -> {finish - start}, {sys.getsizeof(tmp)}')


def map_case():
    start = time.perf_counter()
    tmp = map(lambda x: x if x > low_border else low_border, nums)
    summ = sum(tmp)
    finish = time.perf_counter()
    print(f'map_case: {summ}-> {finish - start}, {sys.getsizeof(tmp)}')


def generator_case():
    start = time.perf_counter()
    tmp = (x if x > low_border else low_border for x in nums)
    summ = sum(tmp)
    finish = time.perf_counter()
    print(f'generator_case: {summ}-> {finish - start}, {sys.getsizeof(tmp)}')


if __name__ == '__main__':
    cycle_case()
    map_case()
    generator_case()
