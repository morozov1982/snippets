TASK_SIZE = 10 ** 1
nums = list(range(TASK_SIZE))

# getter example, no modify
# classic
# while True:  # good idea
idx = 0
while idx < len(nums):
    print(f'{idx + 1} -> {nums[idx]}')  # getter by index
    idx += 1

# python II way
for idx in range(len(nums)):
    print(nums[idx])

# python way
# for el in nums:  # next()
#     print(el)
for idx, el in enumerate(nums, 1):  # next()
    print(f'{idx} -> {el}')
