import time

TASK_SIZE = 10 ** 6
nums = list(range(TASK_SIZE))


def while_case():
    start = time.perf_counter()
    summ = 0
    idx = 0
    while idx < len(nums):
        summ += nums[idx]
        idx += 1
    finish = time.perf_counter()
    print(f'while_case: {summ} -> {finish - start}')


def while_case_2():
    start = time.perf_counter()
    summ = 0
    idx = 0
    len_nums = len(nums)
    while idx < len_nums:
        summ += nums[idx]
        idx += 1
    finish = time.perf_counter()
    print(f'while_case_2: {summ} -> {finish - start}')


def for_in_case():
    start = time.perf_counter()
    summ = 0
    for num in nums:
        summ += num
    finish = time.perf_counter()
    print(f'for_in_case: {summ} -> {finish - start}')


def for_in_enumerate_case():
    start = time.perf_counter()
    summ = 0
    for idx, num in enumerate(nums):
        summ += num
    finish = time.perf_counter()
    print(f'for_in_enumerate_case: {summ} -> {finish - start}')


def for_in_range_case():
    start = time.perf_counter()
    summ = 0
    for idx in range(len(nums)):
        summ += nums[idx]
    finish = time.perf_counter()
    print(f'for_in_range_case: {summ} -> {finish - start}')


if __name__ == '__main__':
    # while_case()
    # while_case_2()
    for_in_case()
    # for_in_enumerate_case()
    # for_in_range_case()
