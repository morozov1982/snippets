import time

TASK_SIZE = 10 ** 6
nums = list(range(TASK_SIZE))


# deepcopy
# nums_2 = nums.copy()
# # nums_2 = nums
# print(id(nums), len(nums))
# print(id(nums_2), len(nums_2))
# nums_2.pop()
# print(len(nums), len(nums_2))


# modify


def while_case():
    _nums = nums.copy()
    start = time.perf_counter()
    idx = 0
    while idx < len(_nums):
        _nums[idx] += 1
        idx += 1
    summ = sum(_nums)
    finish = time.perf_counter()
    print(f'while_case: {summ} -> {finish - start}')


def for_in_case():
    _nums = nums.copy()
    start = time.perf_counter()
    for num in _nums:
        num += 1
    summ = sum(_nums)
    finish = time.perf_counter()
    print(f'for_in_case: {summ} -> {finish - start}')


def for_in_enumerate_case():
    _nums = nums.copy()
    start = time.perf_counter()
    for idx, num in enumerate(_nums):
        _nums[idx] += 1
    summ = sum(_nums)
    finish = time.perf_counter()
    print(f'for_in_enumerate_case: {summ} -> {finish - start}')


def for_in_range_case():
    _nums = nums.copy()
    start = time.perf_counter()
    for idx in range(len(nums)):
        _nums[idx] += 1
    summ = sum(_nums)
    finish = time.perf_counter()
    print(f'for_in_range_case: {summ} -> {finish - start}')


if __name__ == '__main__':
    while_case()
    for_in_case()
    for_in_enumerate_case()
    for_in_range_case()
