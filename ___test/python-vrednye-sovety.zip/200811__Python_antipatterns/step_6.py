# from my_module import say_hello
from my_module import *

from math import *
from numpy import *

# import sys, os, shutil

# import numpy as np

# do not use lazy calc of "or", "and"

say_hello('Den')

print(max(5, 10))
