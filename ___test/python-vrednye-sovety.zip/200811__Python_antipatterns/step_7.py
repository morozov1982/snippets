a = ''  # immutable
a += 'Привет'  # new object
a += ', '  # new object
a += 'всем'  # new object
a += '!'  # new object

print(a)

a_src = ['Привет', ', ', 'всем', '!']  # mutable
a = ''
for el in a_src:
    a += el
print(a)

a = ''.join(a_src)
print(a)
