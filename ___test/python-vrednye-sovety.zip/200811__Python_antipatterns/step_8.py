name = 'Иван'
say_greeting = 'Добрый вечер, %s!' % name
print(say_greeting)

say_greeting = f'Добрый вечер, {name}!'
print(say_greeting)

# say_greeting = 'Добрый вечер, {}!'.format(name)
# print(say_greeting)
