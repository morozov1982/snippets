import os

found = [
    os.path.join(root, file)
    for root, dirs, files in os.walk('.')
    for file in files
    if file.endswith('.py')
]
print(f'found {len(found)}')

found_2 = []
for root, dirs, files in os.walk('.'):
    for file in files:
        if file.endswith('.py'):
            found_2.append(os.path.join(root, file))
print(f'found {len(found_2)}')

found_3 = [file for file in os.listdir('.') if file.endswith('.py')]
print(f'found {len(found_3)}')

found_4 = []
for file in os.listdir('.'):
    if file.endswith('.py'):
        found_4.append(file)
print(f'found {len(found_4)}')
